gecko_sdk_4.5.1/platform/middleware/glib/glib/glib_bitmap.o: \
 C:/Users/alexa/SimplicityStudio/SDKs/gecko_sdk/platform/middleware/glib/glib/glib_bitmap.c \
 c:\users\alexa\simplicitystudio\sdks\gecko_sdk\platform\common\toolchain\inc\sl_gcc_preinclude.h \
 c:\users\alexa\simplicitystudio\sdks\gecko_sdk\platform\middleware\glib\em_types.h \
 C:/Users/alexa/SimplicityStudio/SDKs/gecko_sdk/platform/middleware/glib/glib/glib.h \
 C:/Users/alexa/SimplicityStudio/SDKs/gecko_sdk/platform/middleware/glib/glib/glib_color.h \
 C:\Users\alexa\SimplicityStudio\v5_workspace\Test\config/glib_config.h \
 c:\users\alexa\simplicitystudio\sdks\gecko_sdk\platform\middleware\glib\dmd\dmd.h
c:\users\alexa\simplicitystudio\sdks\gecko_sdk\platform\common\toolchain\inc\sl_gcc_preinclude.h:
c:\users\alexa\simplicitystudio\sdks\gecko_sdk\platform\middleware\glib\em_types.h:
C:/Users/alexa/SimplicityStudio/SDKs/gecko_sdk/platform/middleware/glib/glib/glib.h:
C:/Users/alexa/SimplicityStudio/SDKs/gecko_sdk/platform/middleware/glib/glib/glib_color.h:
C:\Users\alexa\SimplicityStudio\v5_workspace\Test\config/glib_config.h:
c:\users\alexa\simplicitystudio\sdks\gecko_sdk\platform\middleware\glib\dmd\dmd.h:
