main.o: ../main.c \
 c:\users\alexa\simplicitystudio\sdks\gecko_sdk\platform\common\toolchain\inc\sl_gcc_preinclude.h \
 c:\users\alexa\simplicitystudio\sdks\gecko_sdk\platform\service\system\inc\sl_system_init.h \
 ../App.h
c:\users\alexa\simplicitystudio\sdks\gecko_sdk\platform\common\toolchain\inc\sl_gcc_preinclude.h:
c:\users\alexa\simplicitystudio\sdks\gecko_sdk\platform\service\system\inc\sl_system_init.h:
../App.h:
