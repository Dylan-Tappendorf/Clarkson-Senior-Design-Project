#include "sl_system_init.h"

#include "App.h"

int main(void)
{
    // Initialize Silicon Labs system and services
    sl_system_init();

    // Initialize our application
    App_Init();

    while (1)
    {
        App_ProcessAction();
    }
}
