#include "em_cmu.h"
#include "em_gpio.h"

#include "App.h"
#include "sl_sleeptimer.h"

// LED0
#define LED0_PORT  gpioPortH
#define LED0_PIN   11       // PH10 = LED0 Red

// LED1
#define LED1_PORT  gpioPortH
#define LED1_PIN   13       // PH13 = LED1 Red

void App_Init(void)
{
    CMU_ClockEnable(cmuClock_GPIO, true);

    // Both LEDs are active-low.
    // 1 = OFF
    GPIO_PinModeSet(LED0_PORT,
                    LED0_PIN,
                    gpioModePushPull,
                    1);

    GPIO_PinModeSet(LED1_PORT,
                    LED1_PIN,
                    gpioModePushPull,
                    1);
}

void App_ProcessAction(void)
{
    // Toggle both red LEDs
    GPIO_PinOutToggle(LED0_PORT, LED0_PIN);
    GPIO_PinOutToggle(LED1_PORT, LED1_PIN);

    // Wait 500 ms
    sl_sleeptimer_delay_millisecond(500);
}
